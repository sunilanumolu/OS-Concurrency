#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <pthread.h>

void *enterAcademy();
void *meetOrganizer();
void *enterCourt();
void *warmUp();
void *adjustEquipment();
void *startGame();

pthread_mutex_t mutex_check, mutex_playersAtorg, mutex_refferesAtorg, mutex_playersQueue, mutex_refferesQueue;
int *queue_of_players;
int *queue_of_refferes;
int players_in_queue;
int refferes_in_queue;
int players_at_organizer;
int refferes_at_organizer;
int check_organizer;

struct person
{
	int person_id;
	int person_type;
};

struct id_for_person
{
    int id1;
    int id2;
    int id3;
};

void *enterAcademy(void *pperson)
{
	struct person *Person = (struct person*)pperson;
	if( Person->person_type == 1)
	{
		printf("Player %d entered Academy\n",Person->person_id);
		pthread_mutex_lock(&mutex_playersQueue);
		queue_of_players[players_in_queue] = Person->person_id;
		players_in_queue = players_in_queue + 1;
		pthread_mutex_unlock(&mutex_playersQueue);
		pthread_mutex_lock(&mutex_playersAtorg);
		players_at_organizer = players_at_organizer + 1;
		pthread_mutex_unlock(&mutex_playersAtorg);

	}
	else if( Person->person_type != 1)
	{
		printf("Refferee %d entered Academy\n", Person->person_id);
		pthread_mutex_lock(&mutex_refferesQueue);
		queue_of_refferes[refferes_in_queue] = Person->person_id;
		refferes_in_queue = refferes_in_queue + 1;
		pthread_mutex_unlock(&mutex_refferesQueue);
		pthread_mutex_lock(&mutex_refferesAtorg);
		refferes_at_organizer = refferes_at_organizer + 1;
		pthread_mutex_unlock(&mutex_refferesAtorg);
	}
	meetOrganizer(Person->person_id,Person->person_type);

}

void *meetOrganizer(int id,int type)
{
	/*waiting for the organizer*/
	while( check_organizer != 0 );

	int player1_id,player2_id;
	int refferee_id;
	int num1,num2;

	if( check_organizer == 0)
	{
		if( type != 1 )
		{
			printf("Refferee %d meet Organizer.\n",id);
		}
		else if( type != 0 )
		{
			printf("Player %d meet Organizer.\n",id);
		}

		if( players_at_organizer >= 2 && refferes_at_organizer >= 1)
		{
			pthread_mutex_lock(&mutex_check);
			check_organizer = 1;
			pthread_mutex_unlock(&mutex_check);
			pthread_mutex_lock(&mutex_playersQueue);
			num1 = players_in_queue - players_at_organizer;
			player1_id = queue_of_players[num1];
			player2_id = queue_of_players[num1 + 1];
			pthread_mutex_unlock(&mutex_playersQueue);
			pthread_mutex_lock(&mutex_playersAtorg);
			players_at_organizer = players_at_organizer -2;
			pthread_mutex_unlock(&mutex_playersAtorg);
			pthread_mutex_lock(&mutex_refferesQueue);
			num2 = refferes_in_queue - refferes_at_organizer;
			refferee_id = queue_of_refferes[num2];
			pthread_mutex_unlock(&mutex_refferesQueue);
			pthread_mutex_lock(&mutex_refferesAtorg);
			refferes_at_organizer = refferes_at_organizer - 1;
			pthread_mutex_unlock(&mutex_refferesAtorg);
			enterCourt(player1_id,player2_id,refferee_id);
		}
	}
}

void *enterCourt(int player1_id,int player2_id,int refferee_id)
{
	printf("Players %d, %d and Refferee %d entered the court \n", player1_id,player2_id,refferee_id);
	pthread_t tid_player,tid_play,tid_refferee;

	struct id_for_person idsOfPerson;
	idsOfPerson.id1 = player1_id;
	idsOfPerson.id2 = player2_id;
	idsOfPerson.id3 = refferee_id;

	pthread_create(&tid_refferee,NULL,adjustEquipment,&idsOfPerson);
	pthread_create(&tid_player,NULL,warmUp,&idsOfPerson);
	pthread_join(tid_refferee,NULL);
	pthread_join(tid_player,NULL);

	pthread_create(&tid_play,NULL,startGame,&idsOfPerson);
	pthread_mutex_lock(&mutex_check);
	check_organizer = 0;
	pthread_mutex_unlock(&mutex_check);
	pthread_join(tid_play,NULL);

}


void *warmUp(void *idsOfPerson)
{
	struct id_for_person *idsOfPlayers = (struct id_for_person*)idsOfPerson;
	printf("Players %d, %d started warm up.\n", idsOfPlayers->id1, idsOfPlayers->id2);
	sleep(1);

 	int val;
	pthread_exit((void *)&val);
}

void *adjustEquipment(void *idsOfPerson)
{
	struct id_for_person *idsOfPlayers = (struct id_for_person*)idsOfPerson;
	printf("Refferee %d is adjusting equipment.\n", idsOfPlayers->id3);
	sleep(0.5);

	int val;
	pthread_exit((void *)&val);
}

void *startGame(void *idsOfPerson)
{
	struct id_for_person *idsOfPlayers = (struct id_for_person*)idsOfPerson;
	printf("Players %d, %d and Refferee %d started the game.\n", idsOfPlayers->id1, idsOfPlayers->id2, idsOfPlayers->id3);
}


int main(int argc, char const *argv[])
{
	int n;
	scanf("%d", &n);
	int no_of_players = 2*n;
	int no_of_refferes = n;
	int rest_of_players = 2*n;
	int rest_of_refferes = n;
	pthread_mutex_init(&mutex_refferesAtorg, NULL);
	pthread_mutex_init(&mutex_playersAtorg, NULL);
	pthread_mutex_init(&mutex_check, NULL);
	pthread_mutex_init(&mutex_refferesQueue, NULL);
	pthread_mutex_init(&mutex_playersQueue, NULL);
	queue_of_players = (int*)malloc(sizeof(int)*no_of_players);
	queue_of_refferes = (int*)malloc(sizeof(int)*no_of_refferes);

	int players_in_queue = 0;
	int refferes_in_queue = 0;
	int players_at_organizer = 0;
	int refferes_at_organizer = 0;
	int check_organizer = 0;

	pthread_t tid[3*n];
	struct person Person[3*n];
	
	int i,p,q;
	for(i=0; rest_of_refferes > 0 || rest_of_players > 0; i=i+1)
	{
		p = rest_of_refferes/(rest_of_refferes + rest_of_players);
		q = rest_of_players/(rest_of_refferes + rest_of_players);

		if( p >= q)
		{
			Person[i].person_id = no_of_refferes - rest_of_refferes + 1;
			Person[i].person_type = 0;
			rest_of_refferes = rest_of_refferes - 1;
			pthread_create(&tid[i], NULL, enterAcademy, &Person[i]);
		}
		else if( p < q )
		{
			Person[i].person_id = no_of_players - rest_of_players + 1;
			Person[i].person_type = 1;
			rest_of_players = rest_of_players - 1;
			pthread_create(&tid[i], NULL, enterAcademy, &Person[i]);	
		}

		sleep(rand()%3);
	}

	for(i=0; i<3*n; i=i+1)
	{
		pthread_join(tid[i],NULL);
	}

	return 0;
}