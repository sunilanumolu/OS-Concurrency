#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/ipc.h>

key_t key = IPC_PRIVATE; /* This is needed */

void swap(int *x, int *y)
{
    int temp = *x;
    *x = *y;
    *y = temp;
}

void merge(int *a,int l, int mid, int h) 
{
   int l1, l2, i,b[100000]={};
   for(l1 = l, l2 = mid + 1, i = l; l1 <= mid && l2 <= h; i++)
      if(a[l1] <= a[l2])
         b[i]=a[l1++];
      else 
         b[i]=a[l2++];
   while(l1 <= mid)    
      b[i++] = a[l1++];
   while(l2 <= h)   
      b[i++] = a[l2++];
   for(i = l; i <= h; i++)
      a[i] = b[i];
   return;
}

int merge_sort(int *a,int low, int high,int ind,pid_t val) 
{
   int mid;
   if(low + 3 < high) 
   {
      mid = (low + high) / 2;
      pid_t pid[1000];
      int status[1000];
      pid[ind]=fork();
      if(pid[ind]==0)
      {
         merge_sort(a,low, mid,ind+1,pid[ind]);
         exit(0);
      }
      else
      { 
         pid[ind+1]=fork();
         if(pid[ind+1]==0)
         {  
            merge_sort(a,mid+1, high,ind+1,pid[ind]);
            exit(0);
         }
         else{
            waitpid(pid[ind], &status[ind], 0);
            waitpid(pid[ind+1], &status[ind+1], 0);
            merge(a,low, mid, high);
         }
      }
   }
   else{
      int i, j, min_idx;
      for (i = low; i < high; i++)
      {
         min_idx = i;
         for (j = i+1; j < high+1; j++)
            if (a[j] < a[min_idx])
               min_idx = j;
         swap(&a[min_idx], &a[i]);
      }
   }
   return val;
}   

int main() 
{ 
   int i=0,n,stat=0,max;
   int *a;
   int shmid;
   scanf("%d",&n);
   shmid = shmget(key, sizeof(int) * n, IPC_CREAT| 0666);
   a = shmat(shmid, 0, 0);
   if(a == (void *)-1) {
      perror("Shmat failed");
      exit(1);
   }
   for (i = 0; i < n; ++i)
   {
      scanf("%d",&a[i]);
   } 
   if(shmid == -1) {
      perror("Shmget failed");
      exit(1);
   }
   max = i - 1;
   pid_t vall = merge_sort(a,0, max,0,-100);
   for(i = 0; i <= max; i++)
      printf("%d ", a[i]);
   printf("\n");
   return 0;
}