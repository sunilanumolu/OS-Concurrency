#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <pthread.h>

int *a;

typedef struct Params {                                                   
    int l,r,ind;                                                              
}par;   

void swap(int *x, int *y)
{
    int temp = *x;
    *x = *y;
    *y = temp;
}

void merge(int *a,int l, int mid, int h) 
{
   int l1, l2, i,b[100000]={};
   for(l1 = l, l2 = mid + 1, i = l; l1 <= mid && l2 <= h; i++)
      if(a[l1] <= a[l2])
         b[i]=a[l1++];
      else 
         b[i]=a[l2++];
   while(l1 <= mid)    
      b[i++] = a[l1++];
   while(l2 <= h)   
      b[i++] = a[l2++];
   for(i = l; i <= h; i++)
      a[i] = b[i];
   return;
}

void *merge_sort(void *args) 
{
   int mid;
   par *mod = args; 
   if(mod->l + 3 < mod->r) 
   {
      mid = (mod->l + mod->r) / 2;
      int val=mod->ind;
      par par1;
      par par2;
      par1.l=mod->l;
      par1.r=mid;
      par1.ind=val+2;
      pthread_t t1;
      pthread_create(&t1, NULL, merge_sort,&par1);
      par2.l=mid+1;
      par2.r=mod->r;
      par2.ind=val+2;
      pthread_t t2;
      pthread_create(&t2, NULL, merge_sort, &par2);
      pthread_join(t1,NULL);
      pthread_join(t2,NULL);
      merge(a,mod->l, mid, mod->r);
   }
   else{
      int i, j, min_idx;
      for (i = mod->l; i < mod->r; i++)
      {
         min_idx = i;
         for (j = i+1; j < mod->r+1; j++)
            if (a[j] < a[min_idx])
               min_idx = j;
         swap(&a[min_idx], &a[i]);
      }
      pthread_exit(NULL);
   }
   return NULL;
}   

int main() 
{ 
   int i=0,n,stat=0,max;
   scanf("%d",&n);
   a=(int*)malloc(sizeof(int)*n);
   for (i = 0; i < n; ++i)
      scanf("%d",&a[i]);
   max = i - 1;
   pthread_t start;
   par pars;
   pars.l=0;
   pars.r=max;
   pars.ind=0;
   pthread_create(&start,NULL,merge_sort,&pars);
   pthread_join(start,NULL);
   for(i = 0; i <= max; i++)
      printf("%d ", a[i]);
   printf("\n");
   return 0;
}
